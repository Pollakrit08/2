module.exports = {
    flowFile: 'flows.json',
    flowFilePretty: true,
    credentialSecret: false,
    safeMode: false,

    // จำเป็น — ให้ Function node ใช้ require() ใน On Start (initialize) ได้
    functionExternalModules: true,

    // จำกัด modules ที่อนุญาต
    functionGlobalContext: {},

    httpAdminCors: {
        origin: "*",
        methods: "GET,PUT,POST,DELETE"
    },
    httpNodeCors: {
        origin: "*",
        methods: "GET,PUT,POST,DELETE,OPTIONS"
    },

    httpNodeMiddleware: function(req, res, next) {
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        next();
    },

    logging: {
        console: { level: "info", metrics: false, audit: false }
    },

    editorTheme: {
        projects: { enabled: false }
    }
}
