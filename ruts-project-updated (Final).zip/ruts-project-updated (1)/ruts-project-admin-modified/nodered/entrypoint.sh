#!/bin/sh
echo "=== Node-RED startup ==="

# ลบ lock files
rm -f /data/flows.json.$$$
rm -f /data/*.lock
rm -f /data/.flows.json.lock

# ติดตั้ง dependencies
echo "Installing dependencies..."
cd /data
npm install node-red-node-mysql jsonwebtoken bcryptjs --save 2>/dev/null || true

# ตรวจสอบว่า install สำเร็จ
if [ -d "/data/node_modules/bcryptjs" ]; then
  echo "✅ bcryptjs installed"
else
  echo "⚠️ bcryptjs not found, retrying..."
  npm install bcryptjs --save
fi

if [ -d "/data/node_modules/jsonwebtoken" ]; then
  echo "✅ jsonwebtoken installed"
else
  echo "⚠️ jsonwebtoken not found, retrying..."
  npm install jsonwebtoken --save
fi

echo "Starting Node-RED..."
exec node-red --userDir /data --settings /data/settings.js
