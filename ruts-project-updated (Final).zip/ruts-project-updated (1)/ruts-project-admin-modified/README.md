# RUTS-008 — ระบบข้อมูลหลักสูตรวิศวกรรมคอมพิวเตอร์

ระบบจัดการข้อมูลหลักสูตรวิศวกรรมคอมพิวเตอร์ มหาวิทยาลัยเทคโนโลยีราชมงคลศรีวิชัย

---

## Tech Stack

| Layer    | Technology             |
|----------|------------------------|
| Frontend | Angular 17 (Standalone) |
| Backend  | Node-RED               |
| Database | MySQL 8.0              |
| DB Admin | phpMyAdmin             |
| Web Server | Nginx (serve Angular) |
| Deploy   | Docker Compose         |

---

## โครงสร้างโปรเจกต์

```
ruts-project/
├── docker-compose.yml
├── README.md
├── db/
│   └── init.sql            # CREATE TABLE + seed data
├── nodered/
│   ├── flows.json          # Node-RED REST API flows
│   └── package.json        # node-red-node-mysql dependency
├── nginx/
│   └── default.conf        # Nginx config สำหรับ Angular
└── frontend/
    └── ruts-008/           # Angular project
        ├── Dockerfile
        ├── angular.json
        ├── package.json
        ├── tsconfig.json
        └── src/
            ├── main.ts
            ├── index.html
            ├── styles.css
            └── app/
                ├── app.component.*
                ├── app.config.ts
                ├── app.routes.ts
                ├── models/
                │   └── program.model.ts
                ├── services/
                │   └── program.service.ts
                └── components/
                    ├── program-list/
                    ├── program-detail/
                    ├── program-form/
                    └── career-list/
```

---

## วิธีติดตั้งและรันระบบ

### ข้อกำหนดเบื้องต้น
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) (รวม Docker Compose)
- Git (optional)

### ขั้นตอนการรัน

```bash
# 1. Clone หรือดาวน์โหลดโปรเจกต์
git clone <repo-url> ruts-project
cd ruts-project

# 2. Build และรันทุก service พร้อมกัน
docker compose up -d --build

# ครั้งแรกจะใช้เวลาสักครู่ เพราะต้อง:
#   - Build Angular (npm install + ng build)
#   - Pull MySQL, Node-RED, phpMyAdmin images
#   - Install node-red-node-mysql

# 3. ตรวจสอบสถานะ service
docker compose ps

# 4. ดู logs
docker compose logs -f
```

### URL ของแต่ละ Service

| Service     | URL                          | หมายเหตุ                    |
|-------------|------------------------------|-----------------------------|
| 🌐 Angular  | http://localhost:8080         | Frontend หลัก               |
| 🔴 Node-RED | http://localhost:1880         | Editor + API                |
| 🗄️ phpMyAdmin | http://localhost:8081       | จัดการ Database             |
| 🐬 MySQL    | localhost:3306                | เชื่อมต่อด้วย client        |

### ข้อมูล Login

**phpMyAdmin / MySQL:**
- Host: `mysql`
- Username: `root`
- Password: `rootpassword`
- Database: `ruts`

---

## การตั้งค่า Node-RED (ครั้งแรก)

หลังจาก `docker compose up` แล้ว Node-RED จะ import flows อัตโนมัติ แต่ต้องตั้งค่า MySQL connection:

1. เปิด http://localhost:1880
2. ดับเบิ้ลคลิกที่ node **"Query programs"** (หรือ node mysql ใดก็ได้)
3. คลิกปุ่ม ✏️ ข้าง Database
4. กรอกข้อมูล:
   - **Host**: `mysql`
   - **Port**: `3306`
   - **User**: `ruts_user`
   - **Password**: `ruts_password`
   - **Database**: `ruts`
5. คลิก **Update** → **Done** → **Deploy** (ปุ่มแดงมุมขวาบน)

> **หมายเหตุ:** ต้องตั้งค่า MySQL config ครั้งเดียว หลังจากนั้น node mysql ทุกตัวจะใช้ config เดียวกัน

---

## หยุดและลบระบบ

```bash
# หยุด service (เก็บข้อมูล)
docker compose down

# หยุด + ลบ volumes (ล้างข้อมูลทั้งหมด)
docker compose down -v

# rebuild ใหม่ทั้งหมด
docker compose up -d --build --force-recreate
```

---

## REST API Reference

Base URL: `http://localhost:1880/api`

### Programs

| Method | Endpoint            | Description          |
|--------|---------------------|----------------------|
| GET    | /programs           | ดึงรายการหลักสูตรทั้งหมด |
| GET    | /programs/:id       | ดึงรายละเอียดหลักสูตร |
| POST   | /programs           | สร้างหลักสูตรใหม่     |
| PUT    | /programs/:id       | แก้ไขหลักสูตร        |
| DELETE | /programs/:id       | ลบหลักสูตร           |

### Careers

| Method | Endpoint                          | Description       |
|--------|-----------------------------------|-------------------|
| GET    | /programs/:programId/careers      | ดึงรายการอาชีพ    |
| GET    | /careers/:id                      | ดึงอาชีพตาม ID   |
| POST   | /programs/:programId/careers      | เพิ่มอาชีพ       |
| PUT    | /careers/:id                      | แก้ไขอาชีพ       |
| DELETE | /careers/:id                      | ลบอาชีพ          |

---

## ตัวอย่างการทดสอบ API (curl)

```bash
# GET ทุก program
curl http://localhost:1880/api/programs

# GET program ตาม ID
curl http://localhost:1880/api/programs/1

# POST สร้าง program ใหม่
curl -X POST http://localhost:1880/api/programs \
  -H "Content-Type: application/json" \
  -d '{
    "curriculum_name_th": "หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมคอมพิวเตอร์",
    "curriculum_name_en": "Bachelor of Engineering Program in Computer Engineering",
    "degree_name_full_th": "วิศวกรรมศาสตรบัณฑิต (วิศวกรรมคอมพิวเตอร์)",
    "degree_name_short_th": "วศ.บ. (วิศวกรรมคอมพิวเตอร์)",
    "degree_name_full_en": "Bachelor of Engineering (Computer Engineering)",
    "degree_name_short_en": "B.Eng. (Computer Engineering)",
    "total_credits": 130
  }'

# PUT แก้ไข program
curl -X PUT http://localhost:1880/api/programs/1 \
  -H "Content-Type: application/json" \
  -d '{
    "curriculum_name_th": "หลักสูตรวิศวกรรมศาสตรบัณฑิต (ฉบับปรับปรุง)",
    "curriculum_name_en": "Bachelor of Engineering Program (Revised)",
    "degree_name_full_th": "วิศวกรรมศาสตรบัณฑิต (วิศวกรรมคอมพิวเตอร์)",
    "degree_name_short_th": "วศ.บ. (วิศวกรรมคอมพิวเตอร์)",
    "degree_name_full_en": "Bachelor of Engineering (Computer Engineering)",
    "degree_name_short_en": "B.Eng. (Computer Engineering)",
    "total_credits": 135
  }'

# DELETE program
curl -X DELETE http://localhost:1880/api/programs/2

# GET careers ของ program 1
curl http://localhost:1880/api/programs/1/careers

# POST career ใหม่
curl -X POST http://localhost:1880/api/programs/1/careers \
  -H "Content-Type: application/json" \
  -d '{"career_name": "นักพัฒนา AI"}'

# PUT แก้ไข career
curl -X PUT http://localhost:1880/api/careers/1 \
  -H "Content-Type: application/json" \
  -d '{"career_name": "วิศวกร AI/ML"}'

# DELETE career
curl -X DELETE http://localhost:1880/api/careers/7
```

---

## การแก้ปัญหาเบื้องต้น

**Angular แสดงหน้าว่าง:**
```bash
docker compose logs web
# ตรวจสอบ build error ใน container
```

**Node-RED เชื่อม MySQL ไม่ได้:**
- ตรวจสอบว่า MySQL container healthcheck ผ่านแล้ว: `docker compose ps`
- ตั้งค่า MySQL config ใน Node-RED ตามขั้นตอนด้านบน
- Host ต้องเป็น `mysql` (ชื่อ service ใน Docker network)

**MySQL ไม่มีข้อมูล:**
```bash
# รัน init.sql ด้วยตัวเอง
docker exec -i ruts_mysql mysql -uroot -prootpassword ruts < db/init.sql
```

**Port ชนกัน:**
แก้ไขใน `docker-compose.yml`:
```yaml
ports:
  - "8082:80"   # เปลี่ยน 8080 เป็น port อื่น
```

---

## License

MIT

---

## การใช้งานกับ Visual Studio Code

### เปิด Workspace
```bash
# วิธีที่ 1: เปิดด้วยคำสั่ง (แนะนำ)
code ruts-project.code-workspace

# วิธีที่ 2: เปิดโฟลเดอร์ปกติ
code ruts-project/
```

### Extensions ที่แนะนำ
VSCode จะแสดง popup "Install Recommended Extensions" อัตโนมัติ กด **Install All** ได้เลย

| Extension | ใช้ทำอะไร |
|---|---|
| Angular Language Service | IntelliSense สำหรับ Angular template |
| Prettier | จัดรูปแบบโค้ดอัตโนมัติ |
| ESLint | ตรวจสอบ TypeScript |
| Docker | จัดการ Container ใน sidebar |
| SQLTools + MySQL Driver | เชื่อมต่อและรัน SQL ใน VSCode |
| Thunder Client | ทดสอบ REST API ใน VSCode |
| Material Icon Theme | ไอคอนไฟล์สวยงาม |
| GitLens | ดู git history |

### Tasks (Ctrl+Shift+P → "Run Task")
| Task | คำอธิบาย |
|---|---|
| 🐳 Docker: Start All | รัน `docker compose up -d --build` |
| 🐳 Docker: Stop | หยุด services ทั้งหมด |
| 🐳 Docker: Logs | ดู logs แบบ realtime |
| 🐳 Docker: Clean Rebuild | ลบ volumes แล้วสร้างใหม่ |
| ⚡ Angular: ng serve | รัน dev server ที่ port 4200 |
| ⚡ Angular: ng build (prod) | build production |
| 🗄️ MySQL: Import init.sql | import SQL ลงฐานข้อมูล |

### ทดสอบ API ด้วย Thunder Client / REST Client
ไฟล์ `.vscode/api-tests.http` มี HTTP requests พร้อมใช้ครบทุก endpoint
- ติดตั้ง extension **REST Client** (humao.rest-client)
- เปิดไฟล์ `.vscode/api-tests.http`
- กด **Send Request** เหนือแต่ละ request

### SQLTools — เชื่อมต่อ MySQL ใน VSCode
1. กด `Ctrl+Shift+P` → "SQLTools: Open Connection"
2. เลือก **ruts MySQL (Docker)**
3. รัน SQL ได้เลยใน VSCode โดยไม่ต้องเปิด phpMyAdmin

