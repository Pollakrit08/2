export const environment = {
  production: true,
  apiUrl: 'http://localhost:1880/api'
};
