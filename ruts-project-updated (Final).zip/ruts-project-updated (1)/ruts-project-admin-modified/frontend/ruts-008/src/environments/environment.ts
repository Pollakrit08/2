export const environment = {
  production: false,
  apiUrl: 'http://localhost:1880/api'
};
