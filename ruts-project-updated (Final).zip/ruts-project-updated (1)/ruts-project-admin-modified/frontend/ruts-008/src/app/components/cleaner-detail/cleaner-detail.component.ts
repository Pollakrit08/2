import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CleanerService } from '../../services/cleaner.service';
import { AuthService } from '../../services/auth.service';
import { Cleaner } from '../../models/cleaner.model';

@Component({
  selector: 'app-cleaner-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
<div class="container" style="padding-top:24px">
  <div *ngIf="loading" class="spinner-wrap"><div class="spinner"></div></div>
  <div *ngIf="errorMsg" class="alert alert-danger">{{ errorMsg }}</div>

  <ng-container *ngIf="!loading && cleaner">
    <div class="page-header">
      <h1 class="page-title">โปรไฟล์แม่บ้าน</h1>
      <div style="display:flex;gap:8px">
        <a routerLink="/cleaners" class="btn btn-secondary">← กลับ</a>
        <!-- ลบได้เฉพาะ admin หรือเจ้าของโปรไฟล์ -->
        <button *ngIf="canDelete()" (click)="deleteCleaner()" class="btn btn-danger">🗑️ ลบโปรไฟล์</button>
      </div>
    </div>

    <!-- Admin tag -->
    <div *ngIf="auth.isAdmin()" class="admin-view-bar">
      ⚙️ <strong>Admin View</strong> — user_id: {{ cleaner.user_id }}
    </div>

    <div class="card profile-card">
      <div class="profile-top">
        <div class="profile-avatar">🧑‍🔧</div>
        <div>
          <div class="profile-fullname" *ngIf="cleaner.first_name">
            {{ cleaner.first_name }} {{ cleaner.last_name }}
          </div>
          <div class="profile-email">{{ cleaner.email }}</div>
          <div class="profile-phone" *ngIf="cleaner.phone">📞 {{ cleaner.phone }}</div>
          <span class="badge" [ngClass]="statusClass(cleaner.status)">{{ statusLabel(cleaner.status) }}</span>
        </div>
      </div>
      <div class="profile-details">
        <div class="detail-field">
          <div class="detail-label">จังหวัดที่รับงาน</div>
          <div class="detail-value">📍 {{ cleaner.province_name || '—' }}</div>
        </div>
        <div class="detail-field">
          <div class="detail-label">ประสบการณ์</div>
          <div class="detail-value">⏱️ {{ cleaner.experience_years }} ปี</div>
        </div>
        <div class="detail-field" *ngIf="cleaner.bio">
          <div class="detail-label">แนะนำตัว</div>
          <div class="detail-value">{{ cleaner.bio }}</div>
        </div>
      </div>
      <div class="profile-actions">
        <a routerLink="/jobs/new" class="btn btn-primary" *ngIf="!auth.isCleaner()">📋 จ้างงานแม่บ้านคนนี้</a>
        <!-- เจ้าของโปรไฟล์หรือ admin ลบได้ -->
        <button *ngIf="canDelete()" (click)="deleteCleaner()" class="btn btn-danger">🗑️ ลบโปรไฟล์</button>
      </div>
    </div>
  </ng-container>
</div>`,
  styles: [`
.profile-card{}
.profile-top{display:flex;gap:20px;align-items:flex-start;margin-bottom:20px}
.profile-avatar{font-size:4rem}
.profile-fullname{font-size:1.2rem;font-weight:700;color:#1a3c2e;margin-bottom:2px}
.profile-email{font-size:.88rem;color:#64748b;margin-bottom:4px}
.profile-phone{font-size:.9rem;color:#475569;margin-bottom:6px}
.profile-details{border-top:1px solid #e8f5ef;padding-top:16px;margin-bottom:20px}
.profile-actions{display:flex;gap:10px;flex-wrap:wrap}
.badge-warning{background:#fef3c7;color:#92400e}
.badge-muted{background:#f1f5f9;color:#64748b}
.admin-view-bar{background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:8px 16px;margin-bottom:16px;font-size:.88rem;color:#92400e}
  `]
})
export class CleanerDetailComponent implements OnInit {
  cleaner: Cleaner | null = null;
  loading = true;
  errorMsg = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private svc: CleanerService,
    public auth: AuthService
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.svc.getCleanerById(id).subscribe({
      next: d => { this.cleaner = d; this.loading = false; },
      error: () => { this.errorMsg = 'ไม่พบโปรไฟล์แม่บ้าน'; this.loading = false; }
    });
  }

  // admin หรือเจ้าของโปรไฟล์เท่านั้นที่ลบได้
  canDelete(): boolean {
    const u = this.auth.currentUser();
    if (!u) return false;
    if (u.role === 'admin') return true;
    return u.role === 'cleaner' && this.cleaner?.user_id === u.user_id;
  }

  deleteCleaner(): void {
    if (!confirm('ยืนยันลบโปรไฟล์นี้?')) return;
    this.svc.deleteCleaner(this.cleaner!.cleaner_id!).subscribe({
      next: () => this.router.navigate(['/cleaners']),
      error: () => this.errorMsg = 'ลบไม่สำเร็จ'
    });
  }

  statusLabel(s: string): string {
    const m: any = { available:'ว่างงาน', busy:'ติดงาน', inactive:'ไม่รับงาน' };
    return m[s] ?? s;
  }
  statusClass(s: string): string {
    const m: any = { available:'badge-success', busy:'badge-warning', inactive:'badge-muted' };
    return m[s] ?? '';
  }
}
