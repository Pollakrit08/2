import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

interface Stats {
  cleaner_count: number;
  completed_count: number;
  province_count: number;
  service_count: number;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  stats: Stats = {
    cleaner_count:   0,
    completed_count: 0,
    province_count:  0,
    service_count:   0
  };
  statsLoading = true;

  services = [
    { icon: '🏠', name: 'ทำความสะอาดบ้านทั่วไป',     desc: 'กวาด ถู เช็ดฝุ่น จัดเรียงของ' },
    { icon: '🔨', name: 'หลังก่อสร้าง',               desc: 'ล้างคราบซีเมนต์ สี ฝุ่น' },
    { icon: '👕', name: 'ซักผ้า/รีดผ้า',               desc: 'ซักผ้า อบแห้ง พับเรียบร้อย' },
    { icon: '🛋️', name: 'พรม/โซฟา',                   desc: 'ดูดฝุ่น ซักแห้ง/น้ำ' },
    { icon: '❄️', name: 'ล้างแอร์/เครื่องใช้ไฟฟ้า',   desc: 'แอร์ ตู้เย็น เครื่องซักผ้า' },
    { icon: '🏢', name: 'ทำความสะอาดสำนักงาน',        desc: 'ออฟฟิศ ห้องประชุม' },
    { icon: '🌿', name: 'ดูแลสวน/ตัดหญ้า',            desc: 'ตัดหญ้า ตัดต้นไม้ กวาดใบไม้' },
    { icon: '🎉', name: 'ทำความสะอาดครั้งพิเศษ',      desc: 'ก่อน/หลังงานเลี้ยง' },
  ];

  steps = [
    { num: '1', title: 'ลงประกาศงาน',   desc: 'ระบุบริการที่ต้องการ วันที่ และที่อยู่' },
    { num: '2', title: 'เลือกแม่บ้าน',  desc: 'ดูโปรไฟล์และประสบการณ์ของแม่บ้าน' },
    { num: '3', title: 'นัดหมายทำงาน', desc: 'ยืนยันการจ้างและรอรับบริการ' },
    { num: '4', title: 'บ้านสะอาด ✨',  desc: 'งานเสร็จ ชำระค่าบริการ' },
  ];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.http.get<Stats>(`${environment.apiUrl}/stats`).subscribe({
      next: (data) => {
        this.stats = data;
        this.statsLoading = false;
      },
      error: () => {
        // fallback ถ้า API ไม่ตอบสนอง
        this.statsLoading = false;
      }
    });
  }
}
