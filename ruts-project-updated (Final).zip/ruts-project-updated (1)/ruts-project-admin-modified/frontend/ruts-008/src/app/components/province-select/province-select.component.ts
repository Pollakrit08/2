import {
  Component, OnInit, Input, Output, EventEmitter,
  forwardRef, HostListener, ElementRef
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { CleanerService } from '../../services/cleaner.service';
import { Province, District } from '../../models/cleaner.model';

@Component({
  selector: 'app-province-select',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './province-select.component.html',
  styleUrls: ['./province-select.component.css'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => ProvinceSelectComponent),
    multi: true
  }]
})
export class ProvinceSelectComponent implements OnInit, ControlValueAccessor {
  @Input() placeholder = '-- เลือกจังหวัด --';
  @Input() invalid = false;
  @Input() showDistrict = false;   // เปิด/ปิด district selector
  @Output() provinceChange = new EventEmitter<Province | null>();
  @Output() districtChange = new EventEmitter<District | null>();

  allProvinces: Province[] = [];
  districts: District[] = [];
  selectedDistrict: District | null = null;
  districtSearch = '';
  districtLoading = false;

  regions = ['กลาง','เหนือ','อีสาน','ตะวันออก','ตะวันตก','ใต้'];
  regionLabels: Record<string,string> = {
    'กลาง':'ภาคกลาง','เหนือ':'ภาคเหนือ','อีสาน':'ภาคตะวันออกเฉียงเหนือ',
    'ตะวันออก':'ภาคตะวันออก','ตะวันตก':'ภาคตะวันตก','ใต้':'ภาคใต้'
  };

  searchText = '';
  isOpen = false;
  selectedProvince: Province | null = null;
  highlightedIndex = -1;

  private onChange: (val: number | null) => void = () => {};
  private onTouched: () => void = () => {};

  constructor(private svc: CleanerService, private elRef: ElementRef) {}

  ngOnInit(): void {
    this.svc.getProvinces().subscribe({ next: d => this.allProvinces = d });
  }

  get filteredProvinces(): Province[] {
    if (!this.searchText.trim()) return this.allProvinces;
    return this.allProvinces.filter(p => p.province_name.includes(this.searchText.trim()));
  }

  get filteredDistricts(): District[] {
    if (!this.districtSearch.trim()) return this.districts;
    return this.districts.filter(d => d.district_name.includes(this.districtSearch.trim()));
  }

  getByRegion(region: string): Province[] {
    return this.filteredProvinces.filter(p => p.region === region);
  }

  hasResults(): boolean { return this.filteredProvinces.length > 0; }

  openDropdown(): void {
    this.isOpen = true;
    this.searchText = '';
    this.highlightedIndex = -1;
    setTimeout(() => {
      this.elRef.nativeElement.querySelector('.ps-search-input')?.focus();
    }, 50);
  }

  closeDropdown(): void {
    this.isOpen = false;
    this.searchText = '';
    this.onTouched();
  }

  selectProvince(province: Province): void {
    this.selectedProvince = province;
    this.selectedDistrict = null;
    this.districts = [];
    this.districtSearch = '';
    this.onChange(province.province_id);
    this.provinceChange.emit(province);
    this.closeDropdown();

    if (this.showDistrict) {
      this.districtLoading = true;
      this.svc.getDistricts(province.province_id).subscribe({
        next: d => { this.districts = d; this.districtLoading = false; },
        error: () => { this.districtLoading = false; }
      });
    }
  }

  selectDistrict(district: District): void {
    this.selectedDistrict = district;
    this.districtChange.emit(district);
  }

  clearDistrict(): void {
    this.selectedDistrict = null;
    this.districtChange.emit(null);
  }

  clearProvince(event: Event): void {
    event.stopPropagation();
    this.selectedProvince = null;
    this.selectedDistrict = null;
    this.districts = [];
    this.onChange(null);
    this.provinceChange.emit(null);
    this.districtChange.emit(null);
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    if (!this.elRef.nativeElement.contains(event.target) && this.isOpen) {
      this.closeDropdown();
    }
  }

  onKeydown(event: KeyboardEvent): void {
    const flat = this.filteredProvinces;
    if (event.key === 'Escape') { this.closeDropdown(); return; }
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      this.highlightedIndex = Math.min(this.highlightedIndex + 1, flat.length - 1);
    }
    if (event.key === 'ArrowUp') {
      event.preventDefault();
      this.highlightedIndex = Math.max(this.highlightedIndex - 1, 0);
    }
    if (event.key === 'Enter' && this.highlightedIndex >= 0) {
      event.preventDefault();
      this.selectProvince(flat[this.highlightedIndex]);
    }
  }

  isHighlighted(province: Province): boolean {
    return this.filteredProvinces.indexOf(province) === this.highlightedIndex;
  }

  // ControlValueAccessor
  writeValue(val: number | null): void {
    if (!val) { this.selectedProvince = null; return; }
    const trySet = () => {
      this.selectedProvince = this.allProvinces.find(p => p.province_id === +val) || null;
    };
    if (this.allProvinces.length > 0) { trySet(); }
    else {
      const t = setInterval(() => {
        if (this.allProvinces.length > 0) { trySet(); clearInterval(t); }
      }, 100);
    }
  }
  registerOnChange(fn: any): void { this.onChange = fn; }
  registerOnTouched(fn: any): void { this.onTouched = fn; }
  setDisabledState(_: boolean): void {}
}
