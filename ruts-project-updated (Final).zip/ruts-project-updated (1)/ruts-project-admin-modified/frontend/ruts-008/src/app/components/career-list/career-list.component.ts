import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProgramService } from '../../services/program.service';
import { Career } from '../../models/program.model';

@Component({
  selector: 'app-career-list',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './career-list.component.html',
  styleUrls: ['./career-list.component.css']
})
export class CareerListComponent implements OnInit {
  @Input() programId!: number;

  careers: Career[] = [];
  loading = false;
  errorMsg = '';
  successMsg = '';

  // Add form
  addForm!: FormGroup;
  showAddForm = false;
  adding = false;

  // Edit state
  editingId: number | null = null;
  editForm!: FormGroup;
  saving = false;

  constructor(
    private fb: FormBuilder,
    private programService: ProgramService
  ) {}

  ngOnInit(): void {
    this.addForm  = this.fb.group({ career_name: ['', [Validators.required, Validators.maxLength(300)]] });
    this.editForm = this.fb.group({ career_name: ['', [Validators.required, Validators.maxLength(300)]] });
    this.loadCareers();
  }

  loadCareers(): void {
    this.loading = true;
    this.programService.getCareers(this.programId).subscribe({
      next: (data) => { this.careers = data; this.loading = false; },
      error: () => { this.errorMsg = 'โหลดข้อมูลอาชีพไม่สำเร็จ'; this.loading = false; }
    });
  }

  toggleAddForm(): void {
    this.showAddForm = !this.showAddForm;
    if (!this.showAddForm) this.addForm.reset();
  }

  addCareer(): void {
    if (this.addForm.invalid) { this.addForm.markAllAsTouched(); return; }
    this.adding = true;
    this.programService.createCareer(this.programId, this.addForm.value).subscribe({
      next: () => {
        this.showMsg('success', 'เพิ่มอาชีพเรียบร้อยแล้ว');
        this.addForm.reset();
        this.showAddForm = false;
        this.adding = false;
        this.loadCareers();
      },
      error: () => { this.showMsg('error', 'เพิ่มอาชีพไม่สำเร็จ'); this.adding = false; }
    });
  }

  startEdit(career: Career): void {
    this.editingId = career.id!;
    this.editForm.patchValue({ career_name: career.career_name });
  }

  cancelEdit(): void {
    this.editingId = null;
    this.editForm.reset();
  }

  saveEdit(careerId: number): void {
    if (this.editForm.invalid) { this.editForm.markAllAsTouched(); return; }
    this.saving = true;
    this.programService.updateCareer(careerId, this.editForm.value).subscribe({
      next: () => {
        this.showMsg('success', 'แก้ไขอาชีพเรียบร้อยแล้ว');
        this.editingId = null;
        this.saving = false;
        this.loadCareers();
      },
      error: () => { this.showMsg('error', 'แก้ไขไม่สำเร็จ'); this.saving = false; }
    });
  }

  deleteCareer(id: number, name: string): void {
    if (!confirm(`ยืนยันการลบอาชีพ "${name}" ?`)) return;
    this.programService.deleteCareer(id).subscribe({
      next: () => {
        this.showMsg('success', 'ลบอาชีพเรียบร้อยแล้ว');
        this.careers = this.careers.filter(c => c.id !== id);
      },
      error: () => this.showMsg('error', 'ลบไม่สำเร็จ')
    });
  }

  private showMsg(type: 'success' | 'error', msg: string): void {
    if (type === 'success') { this.successMsg = msg; this.errorMsg = ''; }
    else { this.errorMsg = msg; this.successMsg = ''; }
    setTimeout(() => { this.successMsg = ''; this.errorMsg = ''; }, 3000);
  }
}
