import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CleanerService } from '../../services/cleaner.service';
import { AuthService } from '../../services/auth.service';
import { Job, Cleaner } from '../../models/cleaner.model';

@Component({
  selector: 'app-job-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './job-detail.component.html',
  styleUrls: ['./job-detail.component.css']
})
export class JobDetailComponent implements OnInit {
  job: Job | null = null;
  availableCleaners: Cleaner[] = [];
  myCleanerProfile: Cleaner | null = null;
  loading = true;
  errorMsg = '';
  successMsg = '';
  selectedCleanerId = '';
  jobId!: number;
  accepting = false;
  completing = false;
  requesting = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private svc: CleanerService,
    public auth: AuthService
  ) {}

  ngOnInit(): void {
    this.jobId = Number(this.route.snapshot.paramMap.get('id'));

    if (this.auth.isAdmin()) {
      this.svc.getCleaners().subscribe({ next: d => this.availableCleaners = d.filter(c => c.status === 'available') });
      this.loadJob();
    } else if (this.auth.isCleaner()) {
      const userId = this.auth.currentUser()?.user_id;
      if (userId) {
        this.svc.getCleaners().subscribe({
          next: d => {
            this.myCleanerProfile = d.find(c => Number(c.user_id) === Number(userId)) || null;
            this.loadJob();
          },
          error: () => this.loadJob()
        });
      } else {
        this.loadJob();
      }
    } else {
      this.loadJob();
    }
  }

  loadJob(): void {
    this.loading = true;

    if (this.auth.isCleaner() && !this.myCleanerProfile) {
      const userId = this.auth.currentUser()?.user_id;
      if (userId) {
        this.svc.getCleaners().subscribe({
          next: d => {
            this.myCleanerProfile = d.find(c => Number(c.user_id) === Number(userId)) || null;
            this._fetchJob();
          },
          error: () => this._fetchJob()
        });
        return;
      }
    }
    this._fetchJob();
  }

  private _fetchJob(): void {
    this.svc.getJobById(this.jobId).subscribe({
      next: d => { this.job = d; this.loading = false; },
      error: () => { this.errorMsg = 'ไม่พบข้อมูลงาน'; this.loading = false; }
    });
  }

  canManage(): boolean {
    const u = this.auth.currentUser();
    if (!u) return false;
    if (u.role === 'admin') return true;
    return this.job?.user_id === u.user_id;
  }

  alreadyAccepted(): boolean {
    if (!this.job || !this.job.cleaners || this.job.cleaners.length === 0) return false;
    const userId = this.auth.currentUser()?.user_id;
    const currentEmail = this.auth.currentUser()?.email;
    for (const c of this.job.cleaners as any[]) {
      if (userId != null && c.user_id != null && Number(c.user_id) === Number(userId)) return true;
      if (this.myCleanerProfile?.cleaner_id != null && c.cleaner_id != null &&
          Number(c.cleaner_id) === Number(this.myCleanerProfile.cleaner_id)) return true;
      if (currentEmail && c.email && c.email === currentEmail) return true;
    }
    return false;
  }

  canComplete(): boolean {
    if (!this.job) return false;
    const s = this.job.status;
    if (s === 'completed' || s === 'cancelled' || s === 'open') return false;
    return this.auth.isAdmin();
  }

  canRequestComplete(): boolean {
    if (!this.job) return false;
    const s = this.job.status;
    if (!this.auth.isCustomer()) return false;
    const u = this.auth.currentUser();
    if (!u || this.job.user_id !== u.user_id) return false;
    return s === 'assigned' || s === 'in_progress';
  }

  requestCompleteJob(): void {
    if (!confirm('ยืนยันว่างานเสร็จสิ้นแล้ว?\nAdmin จะตรวจสอบและยืนยันสถานะอีกครั้ง')) return;
    this.requesting = true;
    this.errorMsg = '';
    this.svc.requestCompleteJob(this.jobId).subscribe({
      next: () => {
        this.successMsg = '📢 แจ้งงานเสร็จเรียบร้อยแล้ว! กำลังรอ Admin ยืนยัน';
        this.requesting = false;
        this.loadJob();
      },
      error: (err: any) => { this.errorMsg = err?.error?.error || 'เกิดข้อผิดพลาด กรุณาลองใหม่'; this.requesting = false; }
    });
  }

  completeJob(): void {
    if (!confirm('ยืนยันงานเสร็จสิ้น? สถานะจะเปลี่ยนเป็น "เสร็จแล้ว"')) return;
    this.completing = true;
    this.errorMsg = '';
    this.svc.completeJob(this.jobId).subscribe({
      next: () => { this.successMsg = '🎉 ยืนยันงานเสร็จสิ้นเรียบร้อยแล้ว!'; this.completing = false; this.loadJob(); },
      error: (err: any) => { this.errorMsg = err?.error?.error || 'เกิดข้อผิดพลาด กรุณาลองใหม่'; this.completing = false; }
    });
  }

  acceptJob(): void {
    if (!this.myCleanerProfile?.cleaner_id) { this.errorMsg = 'ไม่พบข้อมูลโปรไฟล์แม่บ้านของคุณ'; return; }
    if (!confirm('ยืนยันรับงานนี้?')) return;
    this.accepting = true;
    this.svc.assignCleaner(this.jobId, this.myCleanerProfile.cleaner_id).subscribe({
      next: () => {
        this.successMsg = '✅ รับงานเรียบร้อยแล้ว!';
        this.accepting = false;
        this.myCleanerProfile = null;
        this.loadJob();
      },
      error: (err: any) => { this.errorMsg = err?.error?.error || 'รับงานไม่สำเร็จ'; this.accepting = false; }
    });
  }

  cancelAcceptance(): void {
    if (!this.myCleanerProfile?.cleaner_id) return;
    if (!confirm('ยืนยันยกเลิกการรับงานนี้?')) return;
    this.svc.removeAssignment(this.jobId, this.myCleanerProfile.cleaner_id).subscribe({
      next: () => {
        this.successMsg = 'ยกเลิกการรับงานเรียบร้อยแล้ว';
        this.myCleanerProfile = null;
        this.loadJob();
      },
      error: () => { this.errorMsg = 'ยกเลิกไม่สำเร็จ'; }
    });
  }

  assignCleaner(): void {
    if (!this.selectedCleanerId) return;
    this.svc.assignCleaner(this.jobId, +this.selectedCleanerId).subscribe({
      next: () => { this.successMsg = 'มอบหมายแม่บ้านเรียบร้อยแล้ว'; this.loadJob(); },
      error: () => { this.errorMsg = 'มอบหมายงานไม่สำเร็จ'; }
    });
  }

  removeAssignment(cleanerId: number): void {
    if (!confirm('ยืนยันยกเลิกการมอบหมายแม่บ้านคนนี้?')) return;
    this.svc.removeAssignment(this.jobId, cleanerId).subscribe({
      next: () => { this.successMsg = 'ยกเลิกการมอบหมายเรียบร้อยแล้ว'; this.loadJob(); },
      error: () => { this.errorMsg = 'ยกเลิกไม่สำเร็จ'; }
    });
  }

  deleteJob(): void {
    if (!confirm('ยืนยันลบประกาศงานนี้?')) return;
    this.svc.deleteJob(this.jobId).subscribe({
      next: () => this.router.navigate(['/jobs']),
      error: () => { this.errorMsg = 'ลบไม่สำเร็จ'; }
    });
  }

  statusLabel(s: string): string {
    const m: any = { open:'เปิดรับ', assigned:'มีแม่บ้าน', in_progress:'กำลังทำ', pending_completion:'รอยืนยันเสร็จ', completed:'เสร็จแล้ว', cancelled:'ยกเลิก' };
    return m[s] ?? s;
  }

  statusClass(s: string): string {
    const m: any = { open:'badge-primary', assigned:'badge-warning', in_progress:'badge-info', pending_completion:'badge-pending', completed:'badge-success', cancelled:'badge-muted' };
    return m[s] ?? '';
  }

  isCustomerOf(): boolean {
    const u = this.auth.currentUser();
    return !!u && this.job?.user_id === u.user_id;
  }
}
