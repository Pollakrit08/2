import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ProgramService } from '../../services/program.service';
import { Program } from '../../models/program.model';

@Component({
  selector: 'app-program-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './program-list.component.html',
  styleUrls: ['./program-list.component.css']
})
export class ProgramListComponent implements OnInit {
  programs: Program[] = [];
  loading = true;
  errorMsg = '';
  successMsg = '';

  constructor(private programService: ProgramService) {}

  ngOnInit(): void {
    this.loadPrograms();
  }

  loadPrograms(): void {
    this.loading = true;
    this.errorMsg = '';
    this.programService.getPrograms().subscribe({
      next: (data) => {
        this.programs = data;
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'ไม่สามารถโหลดข้อมูลได้ กรุณาตรวจสอบการเชื่อมต่อ Backend';
        this.loading = false;
      }
    });
  }

  deleteProgram(id: number, name: string): void {
    if (!confirm(`ยืนยันการลบหลักสูตร "${name}" ?`)) return;
    this.programService.deleteProgram(id).subscribe({
      next: () => {
        this.successMsg = 'ลบหลักสูตรเรียบร้อยแล้ว';
        this.programs = this.programs.filter(p => p.id !== id);
        setTimeout(() => this.successMsg = '', 3000);
      },
      error: () => {
        this.errorMsg = 'ลบข้อมูลไม่สำเร็จ';
        setTimeout(() => this.errorMsg = '', 3000);
      }
    });
  }
}
