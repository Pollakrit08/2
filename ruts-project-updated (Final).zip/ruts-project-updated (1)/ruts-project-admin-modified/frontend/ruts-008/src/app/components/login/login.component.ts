import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  form!: FormGroup;
  loading = false;
  errorMsg = '';
  showPassword = false;

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      email:    ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  get f() { return this.form.controls; }
  isInvalid(field: string) {
    const c = this.form.get(field);
    return !!(c?.invalid && c.touched);
  }

  onSubmit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.loading = true;
    this.errorMsg = '';

    this.auth.login(this.f['email'].value, this.f['password'].value).subscribe({
      next: (res) => {
        this.loading = false;
        // redirect ตาม role
        if (res.user.role === 'admin')   this.router.navigate(['/jobs']);
        else if (res.user.role === 'cleaner') this.router.navigate(['/cleaners']);
        else this.router.navigate(['/jobs']);
      },
      error: (err) => {
        this.errorMsg = err?.error?.error || 'เข้าสู่ระบบไม่สำเร็จ';
        this.loading = false;
      }
    });
  }
}
