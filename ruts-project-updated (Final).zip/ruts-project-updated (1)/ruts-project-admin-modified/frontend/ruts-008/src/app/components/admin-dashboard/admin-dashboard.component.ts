import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CleanerService } from '../../services/cleaner.service';
import { AuthService } from '../../services/auth.service';
import { Job, Cleaner, User } from '../../models/cleaner.model';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  jobs: Job[] = [];
  cleaners: Cleaner[] = [];
  users: User[] = [];
  stats: any = {};
  loading = true;
  activeTab: 'overview' | 'jobs' | 'cleaners' | 'users' = 'overview';
  successMsg = '';
  errorMsg = '';
  completingJobId: number | null = null;
  private loaded = 0;
  private total = 3;

  constructor(public auth: AuthService, private svc: CleanerService) {}

  ngOnInit(): void { this.loadAll(); }

  loadAll(): void {
    this.loading = true;
    this.loaded = 0;
    this.svc.getJobs().subscribe({
      next: d => { this.jobs = d; this.checkDone(); },
      error: () => this.checkDone()
    });
    this.svc.getCleaners().subscribe({
      next: d => { this.cleaners = d; this.checkDone(); },
      error: () => this.checkDone()
    });
    this.svc.getAdminUsers().subscribe({
      next: d => { this.users = d; this.checkDone(); },
      error: () => this.checkDone()
    });
  }

  checkDone(): void {
    if (++this.loaded >= this.total) { this.loading = false; this.calcStats(); }
  }

  calcStats(): void {
    this.stats = {
      totalJobs: this.jobs.length,
      openJobs: this.jobs.filter(j => j.status === 'open').length,
      completedJobs: this.jobs.filter(j => j.status === 'completed').length,
      totalCleaners: this.cleaners.length,
      availableCleaners: this.cleaners.filter(c => c.status === 'available').length,
      totalUsers: this.users.length,
      customers: this.users.filter(u => u.role === 'customer').length,
    };
  }

  deleteJob(id: number): void {
    if (!confirm('Admin: ยืนยันลบงาน #' + id + '?')) return;
    this.svc.deleteJob(id).subscribe({
      next: () => {
        this.jobs = this.jobs.filter(j => j.job_id !== id);
        this.calcStats();
        this.successMsg = 'ลบงานเรียบร้อย';
        setTimeout(() => this.successMsg = '', 3000);
      },
      error: () => { this.errorMsg = 'ลบไม่สำเร็จ'; setTimeout(() => this.errorMsg = '', 3000); }
    });
  }

  completeJob(id: number): void {
    if (!confirm('Admin: ยืนยันว่างาน #' + id + ' เสร็จสิ้นเรียบร้อยแล้ว?')) return;
    this.completingJobId = id;
    this.errorMsg = '';
    this.svc.completeJob(id).subscribe({
      next: () => {
        const idx = this.jobs.findIndex(j => j.job_id === id);
        if (idx !== -1) this.jobs[idx] = { ...this.jobs[idx], status: 'completed' };
        this.calcStats();
        this.successMsg = `🎉 งาน #${id} เสร็จสิ้นเรียบร้อยแล้ว!`;
        this.completingJobId = null;
        setTimeout(() => this.successMsg = '', 4000);
      },
      error: (err) => {
        this.errorMsg = err?.error?.error || 'เกิดข้อผิดพลาด กรุณาลองใหม่';
        this.completingJobId = null;
        setTimeout(() => this.errorMsg = '', 4000);
      }
    });
  }

  deleteCleaner(id: number): void {
    if (!confirm('Admin: ยืนยันลบแม่บ้าน #' + id + '?')) return;
    this.svc.deleteCleaner(id).subscribe({
      next: () => {
        this.cleaners = this.cleaners.filter(c => c.cleaner_id !== id);
        this.calcStats();
        this.successMsg = 'ลบแม่บ้านเรียบร้อย';
        setTimeout(() => this.successMsg = '', 3000);
      },
      error: () => { this.errorMsg = 'ลบไม่สำเร็จ'; setTimeout(() => this.errorMsg = '', 3000); }
    });
  }

  statusLabel(s: string): string {
    const m: any = { open:'เปิดรับ', assigned:'มีแม่บ้าน', in_progress:'กำลังทำ', completed:'เสร็จแล้ว', cancelled:'ยกเลิก' };
    return m[s] ?? s;
  }
  statusClass(s: string): string {
    const m: any = { open:'badge-primary', assigned:'badge-warning', in_progress:'badge-info', completed:'badge-success', cancelled:'badge-muted' };
    return m[s] ?? '';
  }
  cleanerStatusLabel(s: string): string {
    const m: any = { available:'ว่างงาน', busy:'ติดงาน', inactive:'ไม่รับงาน' };
    return m[s] ?? s;
  }
  cleanerStatusClass(s: string): string {
    const m: any = { available:'badge-success', busy:'badge-warning', inactive:'badge-muted' };
    return m[s] ?? '';
  }
  roleLabel(r: string): string {
    const m: any = { admin:'⚙️ Admin', customer:'🏠 ลูกค้า', cleaner:'🧹 แม่บ้าน' };
    return m[r] ?? r;
  }
  roleClass(r: string): string {
    const m: any = { admin:'role-admin', customer:'role-customer', cleaner:'role-cleaner' };
    return m[r] ?? '';
  }
}
