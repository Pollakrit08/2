import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ProvinceSelectComponent } from '../province-select/province-select.component';

@Component({
  selector: 'app-register-customer',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, ProvinceSelectComponent],
  templateUrl: './register-customer.component.html',
  styleUrls: ['./register-customer.component.css']
})
export class RegisterCustomerComponent implements OnInit {
  form!: FormGroup;
  loading = false;
  successMsg = '';
  errorMsg = '';

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      first_name:       ['', [Validators.required, Validators.maxLength(100)]],
      last_name:        ['', [Validators.required, Validators.maxLength(100)]],
      email:            ['', [Validators.required, Validators.email]],
      phone:            ['', [Validators.required, Validators.pattern('^0[0-9]{8,9}$')]],
      password:         ['', [Validators.required, Validators.minLength(6)]],
      confirm_password: ['', Validators.required],
      province_id:      [null, Validators.required],
    }, { validators: (g: any) =>
      g.get('password')?.value === g.get('confirm_password')?.value ? null : { mismatch: true }
    });
  }

  get f() { return this.form.controls; }
  isInvalid(f: string) { const c = this.form.get(f); return !!(c?.invalid && c.touched); }

  onSubmit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.loading = true;
    const { confirm_password, ...payload } = this.form.value;
    this.auth.register({ ...payload, role: 'customer' }).subscribe({
      next: () => {
        this.successMsg = 'สมัครสำเร็จ! ยินดีต้อนรับสู่ CleanerJob 🎉';
        this.loading = false;
        setTimeout(() => this.router.navigate(['/jobs/new']), 1500);
      },
      error: (err: any) => {
        this.errorMsg = err?.error?.error || 'สมัครไม่สำเร็จ กรุณาลองใหม่';
        this.loading = false;
      }
    });
  }
}
