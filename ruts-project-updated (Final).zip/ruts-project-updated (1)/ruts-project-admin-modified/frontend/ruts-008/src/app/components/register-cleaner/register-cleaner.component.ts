import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ProvinceSelectComponent } from '../province-select/province-select.component';

@Component({
  selector: 'app-register-cleaner',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, ProvinceSelectComponent],
  templateUrl: './register-cleaner.component.html',
  styleUrls: ['./register-cleaner.component.css']
})
export class RegisterCleanerComponent implements OnInit {
  form!: FormGroup;
  loading = false;
  successMsg = '';
  errorMsg = '';

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      first_name:       ['', [Validators.required, Validators.maxLength(100)]],
      last_name:        ['', [Validators.required, Validators.maxLength(100)]],
      email:            ['', [Validators.required, Validators.email]],
      phone:            ['', [Validators.required, Validators.pattern('^0[0-9]{8,9}$')]],
      password:         ['', [Validators.required, Validators.minLength(6)]],
      confirm_password: ['', Validators.required],
      province_id:      [null, Validators.required],
      experience_years: [0,  [Validators.required, Validators.min(0), Validators.max(50)]],
      bio:              ['', Validators.maxLength(500)],
    }, { validators: this.passwordMatch });
  }

  passwordMatch(g: FormGroup) {
    return g.get('password')?.value === g.get('confirm_password')?.value
      ? null : { mismatch: true };
  }

  get f() { return this.form.controls; }
  isInvalid(f: string) { const c = this.form.get(f); return !!(c?.invalid && c.touched); }

  onSubmit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.loading = true;
    const { confirm_password, ...payload } = this.form.value;
    this.auth.register({ ...payload, role: 'cleaner' }).subscribe({
      next: () => {
        this.successMsg = 'สมัครสำเร็จ! ยินดีต้อนรับสู่ CleanerJob 🎉';
        this.loading = false;
        setTimeout(() => this.router.navigate(['/cleaners']), 1500);
      },
      error: (err: any) => {
        this.errorMsg = err?.error?.error || 'สมัครไม่สำเร็จ กรุณาลองใหม่';
        this.loading = false;
      }
    });
  }
}
