import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CleanerService } from '../../services/cleaner.service';
import { AuthService } from '../../services/auth.service';
import { Cleaner } from '../../models/cleaner.model';
import { ProvinceSelectComponent } from '../province-select/province-select.component';

@Component({
  selector: 'app-cleaner-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule, ProvinceSelectComponent],
  templateUrl: './cleaner-list.component.html',
  styleUrls: ['./cleaner-list.component.css']
})
export class CleanerListComponent implements OnInit {
  cleaners: Cleaner[] = [];
  loading = true;
  errorMsg = '';
  successMsg = '';
  filterProvince: number | null = null;

  constructor(private cleanerService: CleanerService, public auth: AuthService) {}

  ngOnInit(): void { this.loadCleaners(); }

  loadCleaners(): void {
    this.loading = true;
    const pid = this.filterProvince ? +this.filterProvince : undefined;
    this.cleanerService.getCleaners(pid).subscribe({
      next: d => { this.cleaners = d; this.loading = false; },
      error: () => { this.errorMsg = 'ไม่สามารถโหลดข้อมูลได้'; this.loading = false; }
    });
  }

  onFilterChange(): void { this.loadCleaners(); }

  // cleaner สามารถลบตัวเองได้, admin ลบได้ทุกคน
  canDelete(cleaner: Cleaner): boolean {
    const u = this.auth.currentUser();
    if (!u) return false;
    if (u.role === 'admin') return true;
    // cleaner เปรียบ user_id ตัวเอง
    return u.role === 'cleaner' && cleaner.user_id === u.user_id;
  }

  deleteCleaner(id: number, name: string): void {
    if (!confirm('ยืนยันลบโปรไฟล์ "' + name + '" ?')) return;
    this.cleanerService.deleteCleaner(id).subscribe({
      next: () => {
        this.successMsg = 'ลบโปรไฟล์เรียบร้อยแล้ว';
        this.cleaners = this.cleaners.filter(c => c.cleaner_id !== id);
        setTimeout(() => this.successMsg = '', 3000);
      },
      error: () => { this.errorMsg = 'ลบไม่สำเร็จ'; setTimeout(() => this.errorMsg = '', 3000); }
    });
  }

  statusLabel(s: string): string {
    const m: any = { available: 'ว่างงาน', busy: 'ติดงาน', inactive: 'ไม่รับงาน' };
    return m[s] ?? s;
  }
  statusClass(s: string): string {
    const m: any = { available: 'badge-success', busy: 'badge-warning', inactive: 'badge-muted' };
    return m[s] ?? '';
  }
}
