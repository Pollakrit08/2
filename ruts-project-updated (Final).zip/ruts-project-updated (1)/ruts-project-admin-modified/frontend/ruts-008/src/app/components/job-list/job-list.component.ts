import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CleanerService } from '../../services/cleaner.service';
import { AuthService } from '../../services/auth.service';
import { Job, Province, ServiceType } from '../../models/cleaner.model';

@Component({
  selector: 'app-job-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './job-list.component.html',
  styleUrls: ['./job-list.component.css']
})
export class JobListComponent implements OnInit {
  jobs: Job[] = [];
  provinces: Province[] = [];
  serviceTypes: ServiceType[] = [];
  loading = true;
  errorMsg = '';
  successMsg = '';
  filterProvince = '';
  filterService = '';
  filterStatus = '';
  completingJobId: number | null = null;

  constructor(private svc: CleanerService, public auth: AuthService) {}

  ngOnInit(): void {
    this.svc.getProvinces().subscribe({ next: d => this.provinces = d });
    this.svc.getServiceTypes().subscribe({ next: d => this.serviceTypes = d });
    this.loadJobs();
  }

  loadJobs(): void {
    this.loading = true;
    const filters: any = {};
    if (this.filterProvince) filters.province_id = +this.filterProvince;
    if (this.filterService)  filters.service_type_id = +this.filterService;
    if (this.filterStatus)   filters.status = this.filterStatus;
    this.svc.getJobs(filters).subscribe({
      next: d => { this.jobs = d; this.loading = false; },
      error: () => { this.errorMsg = 'โหลดข้อมูลไม่สำเร็จ'; this.loading = false; }
    });
  }

  // ตรวจสอบว่าเป็นเจ้าของ job หรือ admin
  canManage(job: Job): boolean {
    const u = this.auth.currentUser();
    if (!u) return false;
    if (u.role === 'admin') return true;
    return job.user_id === u.user_id;
  }

  // ตรวจสอบว่า cleaner รับงานนี้หรือยัง (ตรวจจาก cleaners array ใน job)
  cleanerAccepted(job: Job): boolean {
    const u = this.auth.currentUser();
    if (!u || u.role !== 'cleaner') return false;
    return !!(job.cleaners && job.cleaners.some((c: any) => c.user_id === u.user_id));
  }

  // แสดงปุ่มเสร็จงานหรือไม่
  canComplete(job: Job): boolean {
    if (!job || job.status === 'completed' || job.status === 'cancelled' || job.status === 'open') return false;
    if (this.auth.isAdmin()) return true;
    if (this.auth.isCleaner()) return this.cleanerAccepted(job);
    return false;
  }

  completeJob(job: Job): void {
    if (!job.job_id) return;
    if (!confirm(`ยืนยันว่างาน "${job.service_name}" เสร็จสิ้นเรียบร้อยแล้ว?`)) return;
    this.completingJobId = job.job_id;
    this.errorMsg = '';
    this.svc.completeJob(job.job_id).subscribe({
      next: () => {
        this.successMsg = `🎉 งาน "${job.service_name}" เสร็จสิ้นเรียบร้อยแล้ว!`;
        // อัพเดต status ใน local array โดยไม่ต้อง reload ใหม่
        const idx = this.jobs.findIndex(j => j.job_id === job.job_id);
        if (idx !== -1) this.jobs[idx] = { ...this.jobs[idx], status: 'completed' };
        this.completingJobId = null;
        setTimeout(() => this.successMsg = '', 4000);
      },
      error: (err) => {
        this.errorMsg = err?.error?.error || 'เกิดข้อผิดพลาด กรุณาลองใหม่';
        this.completingJobId = null;
        setTimeout(() => this.errorMsg = '', 4000);
      }
    });
  }

  deleteJob(id: number): void {
    if (!confirm('ยืนยันลบประกาศงานนี้?')) return;
    this.svc.deleteJob(id).subscribe({
      next: () => {
        this.successMsg = 'ลบประกาศงานเรียบร้อยแล้ว';
        this.jobs = this.jobs.filter(j => j.job_id !== id);
        setTimeout(() => this.successMsg = '', 3000);
      },
      error: () => { this.errorMsg = 'ลบไม่สำเร็จ'; setTimeout(() => this.errorMsg = '', 3000); }
    });
  }

  statusLabel(s: string): string {
    const m: any = { open:'เปิดรับ', assigned:'มีแม่บ้าน', in_progress:'กำลังทำ', completed:'เสร็จแล้ว', cancelled:'ยกเลิก' };
    return m[s] ?? s;
  }
  statusClass(s: string): string {
    const m: any = { open:'badge-primary', assigned:'badge-warning', in_progress:'badge-info', completed:'badge-success', cancelled:'badge-muted' };
    return m[s] ?? '';
  }
}
