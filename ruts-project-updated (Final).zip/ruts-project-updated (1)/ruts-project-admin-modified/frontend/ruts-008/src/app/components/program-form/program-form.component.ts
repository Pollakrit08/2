import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProgramService } from '../../services/program.service';

@Component({
  selector: 'app-program-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './program-form.component.html',
  styleUrls: ['./program-form.component.css']
})
export class ProgramFormComponent implements OnInit {
  form!: FormGroup;
  isEditMode = false;
  programId?: number;
  loading = false;
  loadingData = false;
  errorMsg = '';
  successMsg = '';

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private programService: ProgramService
  ) {}

  ngOnInit(): void {
    this.buildForm();
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEditMode = true;
      this.programId = Number(id);
      this.loadProgramData();
    }
  }

  buildForm(): void {
    this.form = this.fb.group({
      curriculum_name_th:   ['', [Validators.required, Validators.maxLength(500)]],
      curriculum_name_en:   ['', [Validators.required, Validators.maxLength(500)]],
      degree_name_full_th:  ['', [Validators.required, Validators.maxLength(300)]],
      degree_name_short_th: ['', [Validators.required, Validators.maxLength(100)]],
      degree_name_full_en:  ['', [Validators.required, Validators.maxLength(300)]],
      degree_name_short_en: ['', [Validators.required, Validators.maxLength(100)]],
      total_credits:        [0, [Validators.required, Validators.min(1), Validators.max(999)]],
      curriculum_format:    [''],
      career_info:          [''],
      advisor_link:         ['', [Validators.pattern('https?://.+')]],
      study_plan_link:      ['', [Validators.pattern('https?://.+')]],
      contact_info:         ['']
    });
  }

  loadProgramData(): void {
    this.loadingData = true;
    this.programService.getProgram(this.programId!).subscribe({
      next: (data) => {
        this.form.patchValue(data);
        this.loadingData = false;
      },
      error: () => {
        this.errorMsg = 'ไม่สามารถโหลดข้อมูลหลักสูตรได้';
        this.loadingData = false;
      }
    });
  }

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.loading = true;
    this.errorMsg = '';
    const payload = this.form.value;

    const action = this.isEditMode
      ? this.programService.updateProgram(this.programId!, payload)
      : this.programService.createProgram(payload);

    action.subscribe({
      next: (res) => {
        this.loading = false;
        this.successMsg = this.isEditMode ? 'แก้ไขข้อมูลเรียบร้อยแล้ว' : 'เพิ่มหลักสูตรเรียบร้อยแล้ว';
        const targetId = this.isEditMode ? this.programId : res.id;
        setTimeout(() => this.router.navigate(['/programs', targetId]), 1200);
      },
      error: () => {
        this.loading = false;
        this.errorMsg = 'บันทึกข้อมูลไม่สำเร็จ กรุณาลองใหม่อีกครั้ง';
      }
    });
  }

  // Convenience getter for template
  get f() { return this.form.controls; }

  isInvalid(field: string): boolean {
    const ctrl = this.form.get(field);
    return !!(ctrl && ctrl.invalid && ctrl.touched);
  }
}
