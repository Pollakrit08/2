import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService, AuthUser } from '../../services/auth.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
<div class="container" style="padding-top:24px;max-width:560px">
  <h1 class="page-title">👤 โปรไฟล์ของฉัน</h1>

  <div class="card profile-card">
    <div class="avatar">{{ roleIcon }}</div>

    <div class="profile-info">
      <div class="profile-name" *ngIf="user?.first_name">
        {{ user?.first_name }} {{ user?.last_name }}
      </div>
      <div class="profile-email">{{ user?.email }}</div>
      <span class="role-badge role-{{user?.role}}">{{ roleLabel }}</span>
    </div>

    <div class="profile-fields">
      <div class="pf-row">
        <span class="pf-label">ชื่อ-นามสกุล</span>
        <span class="pf-val">
          {{ (user?.first_name && user?.last_name) ? user?.first_name + ' ' + user?.last_name : '—' }}
        </span>
      </div>
      <div class="pf-row">
        <span class="pf-label">อีเมล</span>
        <span class="pf-val">{{ user?.email }}</span>
      </div>
      <div class="pf-row">
        <span class="pf-label">User ID</span>
        <span class="pf-val">#{{ user?.user_id }}</span>
      </div>
      <div class="pf-row">
        <span class="pf-label">สิทธิ์</span>
        <span class="pf-val">{{ roleLabel }}</span>
      </div>
    </div>

    <div class="profile-actions">
      <a routerLink="/jobs"     class="btn btn-primary" *ngIf="auth.isCustomer()">📋 ดูประกาศงาน</a>
      <a routerLink="/cleaners" class="btn btn-success" *ngIf="auth.isCleaner()">🧹 ดูแม่บ้าน</a>
      <a routerLink="/jobs"     class="btn btn-primary" *ngIf="auth.isAdmin()">📋 จัดการงาน</a>
      <button (click)="auth.logout()" class="btn btn-danger">🚪 ออกจากระบบ</button>
    </div>
  </div>
</div>`,
  styles: [`
.profile-card{display:flex;flex-direction:column;align-items:center;gap:12px;text-align:center}
.avatar{font-size:4rem}
.profile-name{font-size:1.2rem;font-weight:700;color:#1a3c2e}
.profile-email{font-size:.88rem;color:#64748b;margin-top:2px}
.role-badge{padding:3px 14px;border-radius:20px;font-size:.8rem;font-weight:700;margin-top:4px;display:inline-block}
.role-customer{background:#dbeafe;color:#1e40af}
.role-cleaner{background:#d1fae5;color:#065f46}
.role-admin{background:#fef3c7;color:#92400e}
.profile-fields{width:100%;border-top:1px solid #e8f5ef;padding-top:14px}
.pf-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #f0f4f8;font-size:.9rem}
.pf-label{color:#64748b;font-weight:600}
.pf-val{color:#212529}
.profile-actions{display:flex;gap:10px;flex-wrap:wrap;justify-content:center;padding-top:6px}
  `]
})
export class ProfileComponent {
  constructor(public auth: AuthService) {}
  get user(): AuthUser | null { return this.auth.currentUser(); }
  get roleLabel(): string {
    const m: any = { customer:'ผู้จ้างงาน', cleaner:'แม่บ้าน', admin:'ผู้ดูแลระบบ' };
    return m[this.user?.role ?? ''] ?? '';
  }
  get roleIcon(): string {
    const m: any = { customer:'🏠', cleaner:'🧹', admin:'⚙️' };
    return m[this.user?.role ?? ''] ?? '👤';
  }
}
