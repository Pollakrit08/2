import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CleanerService } from '../../services/cleaner.service';
import { AuthService } from '../../services/auth.service';
import { ServiceType, PriceRate, District } from '../../models/cleaner.model';
import { ProvinceSelectComponent } from '../province-select/province-select.component';

@Component({
  selector: 'app-job-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, ProvinceSelectComponent],
  templateUrl: './job-form.component.html',
  styleUrls: ['./job-form.component.css']
})
export class JobFormComponent implements OnInit {
  form!: FormGroup;
  isEditMode = false;
  jobId?: number;
  serviceTypes: ServiceType[] = [];
  priceRates: PriceRate[] = [];
  estimatedPrice = 0;
  selectedDistrictId: number | null = null;
  loading = false;
  loadingData = false;
  successMsg = '';
  errorMsg = '';

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private svc: CleanerService,
    public auth: AuthService
  ) {}

  ngOnInit(): void {
    // ถ้าไม่ได้ login ให้ redirect ไป login ทันที
    if (!this.auth.getToken()) {
      this.router.navigate(['/login']);
      return;
    }

    // ไม่ใส่ user_id ใน form — server ดึงจาก JWT เอง
    this.form = this.fb.group({
      service_type_id: ['', Validators.required],
      province_id:     [null, Validators.required],
      district_id:     [null],
      address:         ['', Validators.required],
      job_date:        ['', Validators.required],
      hours:           [2, [Validators.required, Validators.min(1), Validators.max(24)]],
      note:            [''],
    });

    this.svc.getServiceTypes().subscribe({ next: d => this.serviceTypes = d });
    this.svc.getPriceRates().subscribe({ next: d => this.priceRates = d });

    this.form.get('service_type_id')?.valueChanges.subscribe(() => this.calcPrice());
    this.form.get('hours')?.valueChanges.subscribe(() => this.calcPrice());

    const id = this.route.snapshot.paramMap.get('id');
    if (id && id !== 'new') {
      this.isEditMode = true;
      this.jobId = +id;
      this.loadingData = true;
      this.svc.getJobById(this.jobId).subscribe({
        next: d => {
          // ตรวจสอบว่าเป็นเจ้าของหรือ admin
          const u = this.auth.currentUser();
          if (u && u.role !== 'admin' && d.user_id !== u.user_id) {
            this.errorMsg = 'คุณไม่มีสิทธิ์แก้ไขงานของผู้อื่น';
            this.loadingData = false;
            setTimeout(() => this.router.navigate(['/jobs']), 2000);
            return;
          }
          this.form.patchValue(d);
          this.loadingData = false;
          this.calcPrice();
        },
        error: () => { this.errorMsg = 'โหลดข้อมูลไม่สำเร็จ'; this.loadingData = false; }
      });
    }
  }

  onDistrictChange(district: District | null): void {
    this.selectedDistrictId = district?.district_id ?? null;
    this.form.patchValue({ district_id: this.selectedDistrictId });
  }

  calcPrice(): void {
    const stId  = +this.form.get('service_type_id')?.value;
    const hours = +this.form.get('hours')?.value;
    const rate  = this.priceRates.find(r => r.service_type_id === stId);
    this.estimatedPrice = rate && hours ? rate.base_price + rate.price_per_hour * hours : 0;
  }

  isInvalid(f: string) { const c = this.form.get(f); return !!(c?.invalid && c.touched); }

  onSubmit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }

    // ตรวจสอบ login ก่อน submit
    if (!this.auth.getToken()) {
      this.errorMsg = 'Session หมดอายุ กรุณา login ใหม่';
      setTimeout(() => this.router.navigate(['/login']), 1500);
      return;
    }

    this.loading = true;
    // ไม่ส่ง user_id — Node-RED ดึงจาก JWT token เอง
    const payload = { ...this.form.value, total_price: this.estimatedPrice };
    const action  = this.isEditMode
      ? this.svc.updateJob(this.jobId!, payload)
      : this.svc.createJob(payload);

    action.subscribe({
      next: (res: any) => {
        this.successMsg = this.isEditMode ? 'แก้ไขประกาศงานเรียบร้อยแล้ว' : 'ลงประกาศงานเรียบร้อยแล้ว';
        this.loading = false;
        const targetId = this.isEditMode ? this.jobId : res.id;
        setTimeout(() => this.router.navigate(['/jobs', targetId]), 1200);
      },
      error: (err: any) => {
        const msg = err?.error?.error || 'บันทึกไม่สำเร็จ กรุณาลองใหม่';
        this.errorMsg = msg;
        this.loading = false;
      }
    });
  }
}
