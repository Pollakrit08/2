import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ProgramService } from '../../services/program.service';
import { Program, Career } from '../../models/program.model';
import { CareerListComponent } from '../career-list/career-list.component';

@Component({
  selector: 'app-program-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, CareerListComponent],
  templateUrl: './program-detail.component.html',
  styleUrls: ['./program-detail.component.css']
})
export class ProgramDetailComponent implements OnInit {
  program: Program | null = null;
  loading = true;
  errorMsg = '';
  programId!: number;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private programService: ProgramService
  ) {}

  ngOnInit(): void {
    this.programId = Number(this.route.snapshot.paramMap.get('id'));
    this.loadProgram();
  }

  loadProgram(): void {
    this.loading = true;
    this.programService.getProgram(this.programId).subscribe({
      next: (data) => {
        this.program = data;
        this.loading = false;
      },
      error: () => {
        this.errorMsg = 'ไม่พบข้อมูลหลักสูตร';
        this.loading = false;
      }
    });
  }

  deleteProgram(): void {
    if (!this.program) return;
    if (!confirm(`ยืนยันการลบหลักสูตร "${this.program.curriculum_name_th}" ?`)) return;
    this.programService.deleteProgram(this.programId).subscribe({
      next: () => this.router.navigate(['/programs']),
      error: () => { this.errorMsg = 'ลบข้อมูลไม่สำเร็จ'; }
    });
  }
}
