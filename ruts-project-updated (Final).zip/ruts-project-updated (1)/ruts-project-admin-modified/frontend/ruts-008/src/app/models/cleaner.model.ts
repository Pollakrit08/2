export interface Province {
  province_id: number;
  province_name: string;
  region: string;
}

export interface District {
  district_id: number;
  province_id: number;
  district_name: string;
}

export interface User {
  user_id?: number;
  email: string;
  first_name?: string;
  last_name?: string;
  esmil_id?: string;
  phone?: string;
  password?: string;
  role: 'customer' | 'cleaner' | 'admin';
  province_id?: number;
  province_name?: string;
  created_at?: string;
}

export interface Cleaner {
  cleaner_id?: number;
  user_id: number;
  experience_years: number;
  pic?: string;
  status: 'available' | 'busy' | 'inactive';
  province_id?: number;
  province_name?: string;
  bio?: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  phone?: string;
  created_at?: string;
}

export interface ServiceType {
  service_type_id: number;
  service_name: string;
  description?: string;
}

export interface PriceRate {
  price_id: number;
  service_type_id: number;
  service_name?: string;
  base_price: number;
  price_per_hour: number;
}

export interface Job {
  job_id?: number;
  user_id: number;
  service_type_id: number;
  province_id?: number;
  district_id?: number;
  address?: string;
  job_date: string;
  hours: number;
  total_price?: number;
  status: 'open' | 'assigned' | 'in_progress' | 'pending_completion' | 'completed' | 'cancelled';
  note?: string;
  service_name?: string;
  province_name?: string;
  district_name?: string;
  customer_email?: string;
  created_at?: string;
  cleaners?: Cleaner[];
}

export interface JobCleaner {
  job_id: number;
  cleaner_id: number;
  assigned_at?: string;
}
