export interface Program {
  id?: number;
  curriculum_name_th: string;
  curriculum_name_en: string;
  degree_name_full_th: string;
  degree_name_short_th: string;
  degree_name_full_en: string;
  degree_name_short_en: string;
  total_credits: number;
  curriculum_format?: string;
  career_info?: string;
  advisor_link?: string;
  study_plan_link?: string;
  contact_info?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Career {
  id?: number;
  program_id: number;
  career_name: string;
  created_at?: string;
  updated_at?: string;
}
