import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  menuOpen = false;

  constructor(public auth: AuthService) {}

  ngOnInit(): void {
    // ถ้า token หมดอายุแต่ยังมี user ค้างใน localStorage ให้ logout อัตโนมัติ
    if (!this.auth.getToken() && localStorage.getItem('jwt_user')) {
      this.auth.logout();
    }
  }

  get roleLabel(): string {
    const m: any = { customer: 'ผู้จ้างงาน', cleaner: 'แม่บ้าน', admin: 'แอดมิน' };
    return m[this.auth.currentUser()?.role ?? ''] ?? '';
  }

  get roleIcon(): string {
    const m: any = { customer: '🏠', cleaner: '🧹', admin: '⚙️' };
    return m[this.auth.currentUser()?.role ?? ''] ?? '👤';
  }

  closeMenu() { setTimeout(() => this.menuOpen = false, 150); }
}
