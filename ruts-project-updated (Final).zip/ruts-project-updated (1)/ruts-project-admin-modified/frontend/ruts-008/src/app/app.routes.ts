import { Routes } from '@angular/router';
import { HomeComponent }             from './components/home/home.component';
import { LoginComponent }            from './components/login/login.component';
import { ProfileComponent }          from './components/profile/profile.component';
import { RegisterCleanerComponent }  from './components/register-cleaner/register-cleaner.component';
import { RegisterCustomerComponent } from './components/register-customer/register-customer.component';
import { CleanerListComponent }      from './components/cleaner-list/cleaner-list.component';
import { CleanerDetailComponent }    from './components/cleaner-detail/cleaner-detail.component';
import { JobListComponent }          from './components/job-list/job-list.component';
import { JobDetailComponent }        from './components/job-detail/job-detail.component';
import { JobFormComponent }          from './components/job-form/job-form.component';
import { AdminDashboardComponent }   from './components/admin-dashboard/admin-dashboard.component';
import { authGuard, adminGuard, guestGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '',                  component: HomeComponent },
  // Auth
  { path: 'login',             component: LoginComponent,           canActivate: [guestGuard] },
  { path: 'profile',           component: ProfileComponent,         canActivate: [authGuard] },
  { path: 'register-cleaner',  component: RegisterCleanerComponent },
  { path: 'register-customer', component: RegisterCustomerComponent },
  // Admin (เฉพาะ admin เท่านั้น)
  { path: 'admin',             component: AdminDashboardComponent,  canActivate: [authGuard, adminGuard] },
  // Cleaners
  { path: 'cleaners',          component: CleanerListComponent },
  { path: 'cleaners/:id',      component: CleanerDetailComponent },
  // Jobs (ต้อง login เพื่อสร้าง/แก้ไข)
  { path: 'jobs',              component: JobListComponent },
  { path: 'jobs/new',          component: JobFormComponent,  canActivate: [authGuard] },
  { path: 'jobs/:id',          component: JobDetailComponent },
  { path: 'jobs/:id/edit',     component: JobFormComponent,  canActivate: [authGuard] },
  { path: '**',                redirectTo: '' }
];
