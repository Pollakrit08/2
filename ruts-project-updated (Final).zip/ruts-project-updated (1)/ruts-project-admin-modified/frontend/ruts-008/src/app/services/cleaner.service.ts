import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Province, District, User, Cleaner, ServiceType, PriceRate, Job } from '../models/cleaner.model';

@Injectable({ providedIn: 'root' })
export class CleanerService {
  private api = environment.apiUrl;

  constructor(private http: HttpClient) {}

  // ── Provinces ────────────────────────────────────────
  getProvinces(): Observable<Province[]> {
    return this.http.get<Province[]>(`${this.api}/provinces`);
  }

  // ── Districts ─────────────────────────────────────────
  getDistricts(provinceId: number): Observable<District[]> {
    return this.http.get<District[]>(`${this.api}/districts?province_id=${provinceId}`);
  }

  // ── Service Types ────────────────────────────────────
  getServiceTypes(): Observable<ServiceType[]> {
    return this.http.get<ServiceType[]>(`${this.api}/service-types`);
  }

  getPriceRates(): Observable<PriceRate[]> {
    return this.http.get<PriceRate[]>(`${this.api}/price-rates`);
  }

  // ── Cleaners ─────────────────────────────────────────
  getCleaners(provinceId?: number): Observable<Cleaner[]> {
    const url = provinceId
      ? `${this.api}/cleaners?province_id=${provinceId}`
      : `${this.api}/cleaners`;
    return this.http.get<Cleaner[]>(url);
  }

  getCleanerById(id: number): Observable<Cleaner> {
    return this.http.get<Cleaner>(`${this.api}/cleaners/${id}`);
  }

  registerCleaner(data: any): Observable<any> {
    return this.http.post(`${this.api}/cleaners/register`, data);
  }

  updateCleaner(id: number, data: any): Observable<any> {
    return this.http.put(`${this.api}/cleaners/${id}`, data);
  }

  deleteCleaner(id: number): Observable<any> {
    return this.http.delete(`${this.api}/cleaners/${id}`);
  }

  // ── Jobs ─────────────────────────────────────────────
  getJobs(filters?: { province_id?: number; service_type_id?: number; status?: string }): Observable<Job[]> {
    let params = '';
    if (filters) {
      const parts: string[] = [];
      if (filters.province_id)     parts.push(`province_id=${filters.province_id}`);
      if (filters.service_type_id) parts.push(`service_type_id=${filters.service_type_id}`);
      if (filters.status)          parts.push(`status=${filters.status}`);
      if (parts.length) params = '?' + parts.join('&');
    }
    return this.http.get<Job[]>(`${this.api}/jobs${params}`);
  }

  getJobById(id: number): Observable<Job> {
    return this.http.get<Job>(`${this.api}/jobs/${id}`);
  }

  createJob(data: any): Observable<any> {
    return this.http.post(`${this.api}/jobs`, data);
  }

  updateJob(id: number, data: any): Observable<any> {
    return this.http.put(`${this.api}/jobs/${id}`, data);
  }

  deleteJob(id: number): Observable<any> {
    return this.http.delete(`${this.api}/jobs/${id}`);
  }

  // ── Job Assignment ────────────────────────────────────
  assignCleaner(jobId: number, cleanerId: number): Observable<any> {
    return this.http.post(`${this.api}/jobs/${jobId}/assign`, { cleaner_id: cleanerId });
  }

  removeAssignment(jobId: number, cleanerId: number): Observable<any> {
    return this.http.delete(`${this.api}/jobs/${jobId}/assign/${cleanerId}`);
  }

  // ── Complete Job (Admin only) ──────────────────────────
  completeJob(jobId: number): Observable<any> {
    return this.http.post(`${this.api}/jobs/${jobId}/complete`, {});
  }

  // ── Request Complete (Customer → Admin notification) ──
  requestCompleteJob(jobId: number): Observable<any> {
    return this.http.post(`${this.api}/jobs/${jobId}/request-complete`, {});
  }

  // ── Stats ─────────────────────────────────────────────
  getStats(): Observable<any> {
    return this.http.get(`${this.api}/stats`);
  }

  // ── Admin ─────────────────────────────────────────────
  getAdminUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.api}/admin/users`);
  }
}
