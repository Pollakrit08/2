import { Injectable, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';

export interface AuthUser {
  user_id: number;
  email: string;
  first_name?: string;
  last_name?: string;
  role: 'customer' | 'cleaner' | 'admin';
  province_id?: number;
}

export interface LoginResponse {
  token: string;
  user: AuthUser;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private api = environment.apiUrl;
  private _currentUser = signal<AuthUser | null>(this.loadUser());
  currentUser = this._currentUser.asReadonly();

  isLoggedIn = computed(() => !!this._currentUser());
  isAdmin    = computed(() => this._currentUser()?.role === 'admin');
  isCleaner  = computed(() => this._currentUser()?.role === 'cleaner');
  isCustomer = computed(() => this._currentUser()?.role === 'customer');

  get fullName(): string {
    const u = this._currentUser();
    if (!u) return '';
    if (u.first_name && u.last_name) return `${u.first_name} ${u.last_name}`;
    if (u.first_name) return u.first_name;
    return u.email.split('@')[0];
  }

  constructor(private http: HttpClient, private router: Router) {}

  login(email: string, password: string): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.api}/auth/login`, { email, password }).pipe(
      tap(res => this.saveSession(res))
    );
  }

  register(data: any): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.api}/auth/register`, data).pipe(
      tap(res => this.saveSession(res))
    );
  }

  getMe(): Observable<AuthUser> {
    return this.http.get<AuthUser>(`${this.api}/auth/me`).pipe(
      tap(user => {
        this._currentUser.set(user);
        localStorage.setItem('jwt_user', JSON.stringify(user));
      })
    );
  }

  logout(): void {
    localStorage.removeItem('jwt_token');
    localStorage.removeItem('jwt_user');
    this._currentUser.set(null);
    this.router.navigate(['/login']);
  }

  getToken(): string | null {
    const token = localStorage.getItem('jwt_token');
    if (!token) return null;

    // เช็ค token หมดอายุ
    try {
      const base64 = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      const payload = JSON.parse(atob(base64));
      if (payload.exp && Date.now() / 1000 > payload.exp) {
        // Token หมดอายุ → ล้าง session
        localStorage.removeItem('jwt_token');
        localStorage.removeItem('jwt_user');
        this._currentUser.set(null);
        return null;
      }
    } catch {
      return null;
    }

    return token;
  }

  private saveSession(res: LoginResponse): void {
    localStorage.setItem('jwt_token', res.token);
    localStorage.setItem('jwt_user', JSON.stringify(res.user));
    this._currentUser.set(res.user);
  }

  private loadUser(): AuthUser | null {
    try {
      const r = localStorage.getItem('jwt_user');
      return r ? JSON.parse(r) : null;
    } catch {
      return null;
    }
  }
}
