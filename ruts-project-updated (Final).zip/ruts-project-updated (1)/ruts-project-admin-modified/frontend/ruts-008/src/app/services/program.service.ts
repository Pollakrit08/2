import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Program, Career } from '../models/program.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProgramService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  // ── Programs ──────────────────────────────────────────
  getPrograms(): Observable<Program[]> {
    return this.http.get<Program[]>(`${this.apiUrl}/programs`);
  }

  getProgram(id: number): Observable<Program> {
    return this.http.get<Program>(`${this.apiUrl}/programs/${id}`);
  }

  createProgram(program: Program): Observable<any> {
    return this.http.post(`${this.apiUrl}/programs`, program);
  }

  updateProgram(id: number, program: Program): Observable<any> {
    return this.http.put(`${this.apiUrl}/programs/${id}`, program);
  }

  deleteProgram(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/programs/${id}`);
  }

  // ── Careers ───────────────────────────────────────────
  getCareers(programId: number): Observable<Career[]> {
    return this.http.get<Career[]>(`${this.apiUrl}/programs/${programId}/careers`);
  }

  createCareer(programId: number, career: { career_name: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/programs/${programId}/careers`, career);
  }

  updateCareer(careerId: number, career: { career_name: string }): Observable<any> {
    return this.http.put(`${this.apiUrl}/careers/${careerId}`, career);
  }

  deleteCareer(careerId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/careers/${careerId}`);
  }
}
